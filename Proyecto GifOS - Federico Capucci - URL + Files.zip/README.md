# GifOS
Segundo proyecto de Acamica donde pusimos en practica todo lo aprendido de Javascript y afianzamos lo ya conocido de HTML y CSS. 

El proyecto se caracteriza por ser una pagina para buscar GIFs, usando la API de GIPHY, tambien como por la funcionalidad de poder crear y subir tu propios GIFs. 

La totalidad de la pagina fue construida sin Frameworks, y, como se menciono anteriormente, como un trabajo practico.

https://federicocapucci.github.io/GifOS/
